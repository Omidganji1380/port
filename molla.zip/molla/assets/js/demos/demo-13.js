// Demo 13 Js file
$(document).ready(function() {
    'use strict';
});